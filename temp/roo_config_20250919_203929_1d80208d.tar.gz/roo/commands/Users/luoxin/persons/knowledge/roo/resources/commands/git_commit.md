---
name: git_commit
description: "智能生成 Conventional Commits 规范提交"
argument-hint: <scope>
---

**Action**: 委托 `giter` 模式执行提交

**Scope**: 用户指定的 `<scope>`，默认为当前变更文件

**Rules**:
- 遵循 Conventional Commits 规范
- AI 智能分析变更生成提交信息
